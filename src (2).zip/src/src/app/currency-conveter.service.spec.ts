import { TestBed } from '@angular/core/testing';

import { CurrencyConveterService } from './currency-conveter.service';

describe('CurrencyConveterService', () => {
  let service: CurrencyConveterService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CurrencyConveterService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
