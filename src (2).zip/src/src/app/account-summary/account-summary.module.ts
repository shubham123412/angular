import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccountBalanceComponent } from './account-balance/account-balance.component';
import { AccountStatementComponent } from './account-statement/account-statement.component';



@NgModule({
  declarations: [AccountBalanceComponent, AccountStatementComponent],
  imports: [
    CommonModule
  ],
  exports: [AccountBalanceComponent, AccountStatementComponent ]
})
export class AccountSummaryModule { }
