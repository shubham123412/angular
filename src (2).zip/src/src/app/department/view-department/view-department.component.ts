import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { CurrencyConveterService } from 'src/app/currency-conveter.service';
import { Department } from '../department';
import { DepartmentService } from '../department.service';

@Component({
  selector: 'app-view-department',
  templateUrl: './view-department.component.html',
  styleUrls: ['./view-department.component.css']
})
export class ViewDepartmentComponent implements OnInit {

  deptObj: Department;

  constructor(private deptService: DepartmentService) {
    
  }
  ngOnInit() { //3

      this.deptService.findDepartment(this.deptObj.deptNumber)
      .then((data: Department) => {
          this.deptObj = data;
      }, (err) => {
          console.log(err);
      })
      
  }

}
