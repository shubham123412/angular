import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddDepartmentComponent } from './add-department/add-department.component';
import { ViewDepartmentComponent } from './view-department/view-department.component';
import { ViewAllDepartmentComponent } from './view-all-department/view-all-department.component';
import { UpdateDepartmentComponent } from './update-department/update-department.component';
import { DeleteDepartmentComponent } from './delete-department/delete-department.component';
import { HomeComponentComponent } from './home-component/home-component.component';



@NgModule({
  declarations: [AddDepartmentComponent, ViewDepartmentComponent, ViewAllDepartmentComponent, UpdateDepartmentComponent, DeleteDepartmentComponent, HomeComponentComponent],
  imports: [
    CommonModule
  ]
})
export class DepartmentModule { }
