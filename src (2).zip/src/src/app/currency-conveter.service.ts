import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class CurrencyConveterService {

  constructor() { }
  convertCurrency(arg) {
    console.log(arg);
    //actual logic to access the live source currency, target current
    //and amount from the db to do the division / multiplication 
    //to convert the currency - SPRING REST API TO HIT FROM HERE
    
  }
}
