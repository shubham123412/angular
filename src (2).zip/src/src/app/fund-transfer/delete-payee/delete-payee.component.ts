import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-delete-payee',
  templateUrl: './delete-payee.component.html',
  styleUrls: ['./delete-payee.component.css']
})
export class DeletePayeeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
