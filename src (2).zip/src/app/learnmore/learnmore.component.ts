import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-learnmore',
  templateUrl: './learnmore.component.html',
  styleUrls: ['./learnmore.component.css']
})
export class LearnmoreComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
